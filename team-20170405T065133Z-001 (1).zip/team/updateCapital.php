<?
require 'db_connection.php';//change this to your own database authentication file

function getState($StateName){
global $dbConn;

$sql = "SELECT * FROM
USStates u JOIN StateCapitals c ON u.StateId=c.StateId
WHERE StateName = :StateName";
$stmt = $dbConn -> prepare($sql);
$stmt -> execute(array(":StateName"=>$StateName));
return $stmt->fetch(); 
}

if (isset($_POST['save'])) { //checks whether we're coming from "save data" form

$sql = "UPDATE USStates, StateCapitals
SET StateName = :StateName,
CapitalName = :CapitalName,
WHERE StateId = :StateId";
$stmt = $dbConn -> prepare($sql);
$stmt -> execute(array(":StateName"=>$_POST['StateName'],
":CapitalName"=>$_POST['CapitalName'])); 

echo "RECORD UPDATED!! <br> <br>"; 
}

?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">

        <!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame 
Remove this if you use the .htaccess -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <title>Update Capital Info</title>
        <meta name="description" content="Finals, labs, quizzes, assignments and etc for cst336 Spring 2017">
        <meta name="author" content="tawilliams">

        <meta name="viewport" content="width=device-width; initial-scale=1.0">
        <link rel="shortcut icon" href="../favicon.ico">
  <link rel="stylesheet" href="../css/teamProj.css">
    </head>

    <body>
        <div class="wrapper">
            <?

if (isset($_POST['StateName'])) {
$StateInfo = getState($_POST['StateName']); ?>

                <form method="post">
                   <fieldset>
                   <legend> <H2 align='center'>Update Capital/State Form</H2></legend>
                   State Name: <input type="text" name="StateName" value="<?=$StateInfo['StateName']?>" /><br /> Capital Name: <input type="text" name="CapitalName" value="<?=$StateInfo['CapitalName']?>" /><br /> Seal Image File: <input type="text" name="Seal" value="<?php echo 'images/' . str_replace(' ','',$StateInfo['StateName']) . '.png'?>" /><br />
                    <input type="hidden" name="StateId" value="<?=$StateInfo['StateId']?>">
                    <input type="submit" name="save" value="Save">
                       
                   </fieldset>

                </form>

                <? }

?>

        </div>
        <footer class="footer">
            <p><a href="../index.html">Back To Home</a></p>
        </footer>
    </body>

    </html>