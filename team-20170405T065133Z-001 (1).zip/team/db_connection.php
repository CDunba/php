<?php
$host     = "localhost";
$dbname   = "will6400"; //change this to your otterID
$username = "will6400"; //change this to your otter ID
$password = "5275b288d428913"; //change this to your database account password

//establishes database connection
try{
	$dbConn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
}catch(Exception $e){
	echo "Unable to connect to database!";
	exit();
}

//shows errors when connecting to database
$dbConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 


?>