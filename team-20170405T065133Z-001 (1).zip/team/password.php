<?php
session_start();

if(!isset($_SESSION['team_user'])){
header("Location: gp.php");
}

require 'db_connection.php';


function changePassword(){
	$CurrentPassword = $_POST['CurrentPassword'];
	$NewPassword = $_POST['NewPassword'];
	$ConfirmPassword = $_POST['ConfirmPassword'];
	
	    if ($NewPassword !== $ConfirmPassword) {
        	echo "New Password and Confirm Do Not Match!";
			break;
		}elseif (isset ($CurrentPassword)) {
		    	$sql = "SELECT password
				FROM group_login
				WHERE username = ".$_SESSION['team_user'];
		        
		   $stmt = $dbConn -> prepare($sql);
		   $stmt -> execute();
		   $row = $stmt->fetch();

			if (sha1($CurrentPassword)==$row['password']){
		    	$sha1_np = hash('sha1',$_POST['NewPassword']);		
				$sql = "UPDATE group_login SET password =".$sha1_np."WHERE username=".$_SESSION['team_user'];
		
				$stmt = $dbConn -> prepare($sql);
				$stmt -> execute();
				echo("Password Changed!");
		    }else{
		        echo("Error! Current Password incorrect.");
		    }
					
    }   
}   

?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">

        <!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame 
Remove this if you use the .htaccess -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <title>Update Your Password - Result</title>
        <meta name="description" content="Finals, labs, quizzes, assignments and etc for cst336 Spring 2017">
        <meta name="author" content="tawilliams">

        <meta name="viewport" content="width=device-width; initial-scale=1.0">
        <link rel="shortcut icon" href="../favicon.ico">
      <link rel="stylesheet" href="../css/teamProj.css">
    </head>

    <body>
        <div class="wrapper">

            <form method="POST" action="password.php">
                <fieldset>
                    <legend>
                        <h1>Change Password</h1>
                    </legend>
                    <p> Current Password <input type="password" name="CurrentPassword" id="CurrentPassword" required></p>
                    <p>New Password <input type="password" name="NewPassword" id="NewPassword" required></p>
                    <p>Confirm Password <input type="password" name="ConfirmPassword" id="ConfirmPassword" required></p>
                    <input type="submit" name="submit" id="submit" value="Update!">
                </fieldset>


			<?php
			 if(isset($_POST['ConfirmPassword'])){
			    changePassword();
			 }
			?>
            </form>

        </div>
        <footer class="footer">
        	 <p><a href="index.php">Back To Team Project</a> < ----- > </p> 
            <p><a href="../index.html">Back To Main Site</a></p>
        </footer>

    </body>

    </html>