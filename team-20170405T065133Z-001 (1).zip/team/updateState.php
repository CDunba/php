<?
require 'db_connection.php';//change this to your own database authentication file

function getState($StateName){
global $dbConn;

$sql = "SELECT * FROM
USStates u JOIN StateCapitals c ON u.StateId=c.StateId
WHERE StateName = :StateName";
$stmt = $dbConn -> prepare($sql);
$stmt -> execute(array(":StateName"=>$StateName));
return $stmt->fetch(); 
}

if (isset($_POST['save'])) { //checks whether we're coming from "save data" form

$sql = "UPDATE USStates, StateCapitals
SET StateName = :StateName,
CapitalName = :CapitalName,
WHERE StateId = :StateId";
$stmt = $dbConn -> prepare($sql);
$stmt -> execute(array(":StateName"=>$_POST['StateName'],
":CapitalName"=>$_POST['CapitalName'])); 

echo "RECORD UPDATED!! <br> <br>"; 
}

?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">

        <!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame 
Remove this if you use the .htaccess -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <title>Update State Info</title>
        <meta name="description" content="Finals, labs, quizzes, assignments and etc for cst336 Spring 2017">
        <meta name="author" content="tawilliams">

        <meta name="viewport" content="width=device-width; initial-scale=1.0">
        <link rel="shortcut icon" href="../favicon.ico">
      <link rel="stylesheet" href="../css/teamProj.css">
    </head>

    <body>
        <div class="wrapper">
            <H2 align='center'>Update State Information Form</H2><br />

            <?
		
if (isset($_POST['State'])) {
$StateInfo = getState($_POST['State']); ?>


                <form method="post">
                    State Name: <input type="text" name="State" value="<?=$StateInfo['StateName']?>" /><br /> Capital Name: <input type="text" name="Capital" value="<?=$StateInfo['CapitalName']?>" /><br /> Motto: <input type="text" length="80" name="Motto" value="<?=$StateInfo['StateMotto']?>" /><br /> Area in Square Miles: <input type="text" name="AreaSqMi" value="<?=$StateInfo['AreaSqMi']?>" /><br /> State Population: <input type="text" name="State Population" value="<?=$StateInfo['Population']?>" /><br /> State Median Income: <input type="text" name="State Median Income" value="<?=$StateInfo['MedianIncome']?>" /><br /> Capital Population: <input type="text" name="Capital Population" value="<?=$StateInfo['Population']?>" /><br /> Capital Nickname: <input type="text" name="Capital Nickname" value="<?=$StateInfo['NickName']?>" /><br /> Capital Established: <input type="text" name="Capital Establish" value="<?=$StateInfo['YearCapitalEstablished']?>" /><br />
                    <input type="hidden" name="StateId" value="<?=$StateInfo['StateId']?>">
                    <input type="submit" name="save" value="Save">
                </form>

                <? } ?>
                    <br />
                    <h3 align="center"><a href="../index.php">Back</a></h3>

        </div>
        
        <footer class="footer">
            <p><a href="../index.html">Back To Home</a></p>
        </footer>
    </body>

    </html>