SELECT * FROM usstates
     ORDER BY StateName; 
     
SELECT * FROM usstates
     ORDER BY StateName DESC; 
     
SELECT * FROM usstates
     ORDER BY Population; 
     
SELECT * FROM usstates
     ORDER BY MedianIncome; 
     
SELECT AVG(Population) FROM usstates; 

SELECT SUM(MedianIncome) FROM usstates;
     
     