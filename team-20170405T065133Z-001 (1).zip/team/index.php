<?php
session_start();

if(!isset($_SESSION['team_user'])){
header("Location: gp.php");
}

require 'db_connection.php';
/**** Getting all US states and IDs ****/
$sql = "SELECT StateName, StateId 
        FROM USStates 
        ORDER BY StateName ASC";

$stmt = $dbConn -> prepare($sql); //prepares a statement for execution and returns a statement object
$stmt -> execute(); //execute the prepared statement
$stateNames = $stmt->fetchAll(); //store the obtained data into an array variable

/**** Getting USStates based on StateId ****/
if (isset ($_GET['StateInfo'])) {
   $StateId = $_GET['StateInfo'];
   $sql = "SELECT * 
           FROM USStates 
           WHERE StateId = :StateId ";
        
   $stmt = $dbConn -> prepare($sql);
   $stmt -> execute( array (':StateId' => $StateId));
   $StateInfo = $stmt->fetch();
}

/****  Top 5 states with the largest combined population ***/
   function largestPopulation() {
       global $dbConn, $stmt;  //it uses the variables declared previously 
    $sql = "SELECT StateName, Population
            FROM USStates 
            GROUP BY StateName
            ORDER BY Population DESC
            LIMIT 5";
    $stmt = $dbConn -> prepare($sql);
    $stmt -> execute();
    return $stmt->fetchAll();
   }

   /****  States and their Capitals ***/
   function statesAndCapitals() {
       global $dbConn, $stmt;  //it uses the variables declared previously 
    //NOTE: field names MUST match the ones in database, they are case sensitive!
    $sql = "SELECT StateName, CapitalName
            FROM USStates s
            JOIN StateCapitals c ON s.StateId = c.StateId
            ORDER BY StateName";
    $stmt = $dbConn -> prepare($sql);
    $stmt -> execute();
    return $stmt->fetchAll();
   }

	function getCapitals(){
       global $dbConn, $stmt;  //it uses the variables declared previously 
	    
	    $sql = "SELECT u.StateID as StateID, CapitalName, StateName
	            FROM USStates u JOIN StateCapitals c ON u.StateId=c.StateId
	            ORDER BY StateName";
	    $stmt = $dbConn -> prepare($sql);
	    $stmt -> execute();
	    return $stmt->fetchAll();
	}
	
	function getStates(){
       global $dbConn, $stmt;  //it uses the variables declared previously 
	    
	    $sql = "SELECT u.StateID, StateName as State, CapitalName as Capital, StateMotto as Motto, AreaSqMi, 
	    		u.Population as 'State Population', MedianIncome as 'State Median Income', c.Population as 'Capital Population', 
	    		Nickname as 'Capital Nickname', YearCapitalEstablished as 'Capital Established'
	            FROM USStates u JOIN StateCapitals c ON u.StateId=c.StateId
	            ORDER BY StateName";
	    $stmt = $dbConn -> prepare($sql);
	    $stmt -> execute();
	    return $stmt->fetchAll();
	}	
      

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

  <title>Team Project - Assignments 4 & 5</title>

  <meta name="viewport" content="width=device-width; initial-scale=1.0">
  <link rel="shortcut icon" href="../favicon.ico">
  <link rel="stylesheet" href="../css/teamProj.css">
</head>

<body>
<div class="wrapper">
	<header class="header">
      <h2>US States Statistics Portal</h2>
      	<span class="moveRight">
			 <?php

			echo "Welcome " . $_SESSION['user'] . ":  ";
			?>
			<form method="post" action="password.php"> 
				<input type="submit" value="Change Password" /> 
			</form>
			
			<form method="post" action="logout.php">
				<input type="submit" value="Logout" />
			</form>
		</span>
		
		<p class="moveRight"><a href="log.php">View Login Log Data</a></p>
    </header> 

<div class="item">
     <form action="" method="GET">
     	<fieldset>
     		<legend><h2> US States and Queries </h2></legend>
                    <select name="StateInfo">
           <option value="-1"> - Select State -</option>
           <?php
                foreach ($stateNames as $state) {
                    echo "<option  value=" . $state['StateId'] . ">" . $state['StateName'] . "</option>";
                
                //foreach provides an easy way to iterate over arrays. foreach works only on arrays and objects.

                //In the above statement, it loops over $stateNames array. On each iteration, the value of the current element is assigned to $team and the internal array pointer is advanced by one (so on the next iteration, you'll be looking at the next element).
                
                }         
             
           ?>   
         </select>
         <input type="submit" value="Get State Info!" />
         </fieldset>
     </form>
   
     <?php
    
        if (isset($StateInfo) && !empty($StateInfo)) {
            echo "<b>State Name: </b>" . $StateInfo['StateName'] . "<br />";
            echo "<b>Motto: </b>" . $StateInfo['StateMotto'] . "<br />";
            echo "<b>Population: </b>" . $StateInfo['Population'] . "<br />";
            echo "<b>Area: </b>" . $StateInfo['AreaSqMi'] . " mi&sup2; <br />";
            echo "<b>Median Income: </b>" . $StateInfo['MedianIncome'] . "<br />";
        }
    
    ?>
    
    <br />
    <strong>Top 5 states with the largest population</strong>
    <br />

     <?php
        $records = largestPopulation();
        foreach ($records as $record) {
          echo $record['StateName'] . " - " . $record['Population']  . "<br />";
        } 
    ?>

    
<?php	

	$statesList = getStates();
    
?>
</div>

<div class="item">

    <H3><center>List of all states and their capitals</center></H3>
    <table>
    	<tr>
    		<td><b>State</b></td><td><b>Capital</b></td><td><b>Seal</b></td><td><b>Update</b></td><td><b>Delete</b></td>
	 	</tr>   

	<?php 
	$capitalsList = getCapitals();
	foreach ($capitalsList as $capital) { ?>
	     <tr>
			<td><?=$capital['StateName']?></td>
			<td><?=$capital['CapitalName']?></td>
			<td><img src=<?php echo 'images/' . str_replace(' ','',$capital['StateName']) . '.png'?> width='100px'></td>
		    <td><form action="updateCapital.php" method="post">
		            <input type="hidden" name="StateId" value="<?=$capital['StateId']?>">
		            <input type="hidden" name="StateName" value="<?=$capital['StateName']?>">
		            <input type="hidden" name="CapitalName" value="<?=$capital['CapitalName']?>">
		           <!-- <input type="hidden" name="Seal" value="<?php echo 'images/' . str_replace(' ','',$capital['StateName']) . '.png'?>"> -->
		            <input type="submit" name="update" value="Update">
		    </form></td>
		    <td><form method="post" onsubmit="confirmDelete('<?=$capital['CapitalName']?>')" >
		            <input type="hidden" name="StateId" value="<?=$capital['StateId']?>">            
		            <input type="submit" name="delete" value="Delete">
	     	</form></td>
		</tr>
	<?  } //end foreach ?>
	 </table>
	</div>
	 
</div>
        <footer class="footer">
        	 <p><a href="index.php">Back To Team Project</a> < ----- > </p> 
            <p><a href="../index.html">Back To Main Site</a></p>
        </footer>
</body>
</html>