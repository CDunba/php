<?php

session_start();

if (isset($_POST['username'])){
require 'db_connection.php';

$sql = "SELECT *
FROM group_login
WHERE username = :username
AND password = :password";

$stmt = $dbConn -> prepare($sql);
$stmt -> execute(array(":username" => $_POST['username'], ":password" => hash("sha1", $_POST['password'])));

$record = $stmt -> fetch();

	if (empty($record)){
		echo "Wrong username/password!";
	} else {
		$_SESSION['team_user'] = $record['username'];
		$_SESSION['user'] = $record['firstname'] . " " . $record['lastname'];
		
		$sql2 = "INSERT INTO login_log
		(username)
		VALUES
		(:username)";
				
		$stmt2 = $dbConn -> prepare($sql2);
		$stmt2 -> execute(array(":username" => $_SESSION['team_user']));
						
		header("Location: index.php");
	}
}

?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <title>Team Project - Assignments 4 & 5</title>

        <meta name="viewport" content="width=device-width; initial-scale=1.0">
        <link rel="shortcut icon" href="../favicon.ico">
        <link rel="stylesheet" href="../css/team.css">
    </head>

    <body>
        <div class="wrapper">
            <form method="post">
                <fieldset>
                    <legend>
                        <h1>Welcome to the US States Statistics Portal</h1>
                    </legend>
                    Username: <input type="text" name="username" value="twilliams" /><br />
                    <p></p>
                    Password: <input type="password" name="password" value="0tters" /><br />
                    <p></p>
                    <input type="submit" value="Login" />
                    <p></p>
                </fieldset>

                <span><center>Credentials are supplied for testing only.</center>
 
</span>
            </form>

        </div>

        <footer class="footer">
        	 <p><a href="index.php">Back To Team Project</a> < ----- > </p> 
            <p><a href="../index.html">Back To Main Site</a></p>        </footer>
    </body>

    </html>