<?php
session_start();

if(!isset($_SESSION['team_user'])){
header("Location: gp.php");
}

require 'db_connection.php';

   function getLogData() {
       global $dbConn, $stmt;  //it uses the variables declared previously 
    $sql = "SELECT *
            FROM login_log";
    $stmt = $dbConn -> prepare($sql);
    $stmt -> execute();
    return $stmt->fetchAll();
   }
   
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

  <title>Team Project - Assignments 4 & 5</title>

  <meta name="viewport" content="width=device-width; initial-scale=1.0">
  <link rel="shortcut icon" href="../favicon.ico">
  <link rel="stylesheet" href="../css/teamProj.css">
</head>

<body>
<div class="wrapper">
	<header class="header">
      <h2>US States Statistics Portal Login Log</h2>
      	<span class="moveRight">
			 <?php

			echo "Welcome " . $_SESSION['user'] . ":  ";
			?>
			<br>
			<form method="post" action="password.php"> 
				<input type="submit" value=" Change Password " /> 
			</form>
			
			<form method="post" action="logout.php">
				<input type="submit" value=" Logout " />
			</form>
			
		</span>
		
			<p class="moveRight"><a href="log.php">View Login Log Data</a></p>

    </header> 

	<div class="item">
     <?php
        $records = getLogData();
        echo "<table><tr><td>Username</td><td>Login Date/Time</td></tr>";
        foreach ($records as $record) {
          echo "<tr><td>". $record['username'] . "</td><td>" . $record['loginDate']  . "</td></tr>";
        } 
		echo "</table>";
    	?>
	</div>
	 
</div>
    <footer class="footer">
        	 <p><a href="index.php">Back To Team Project</a> < ----- > </p> 
            <p><a href="../index.html">Back To Main Site</a></p>    </footer>
</body>
</html>