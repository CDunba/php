
  <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">

        <!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame 
Remove this if you use the .htaccess -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <title>Create Tables - (Only Need Once!)</title>
        <meta name="description" content="Finals, labs, quizzes, assignments and etc for cst336 Spring 2017">
        <meta name="author" content="tawilliams">

        <meta name="viewport" content="width=device-width; initial-scale=1.0">
        <link rel="shortcut icon" href="../favicon.ico">
      <link rel="stylesheet" href="../css/teamProj.css">
    </head>

    <body>
        <div class="wrapper">

<?php

require 'db_connection.php';

$sql = "CREATE TABLE IF NOT EXISTS group_login (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	firstname varchar (50),
	lastname varchar (50),
	username varchar (50) NOT NULL,
	password varchar (50) NOT NULL)";

$stmt = $dbConn -> prepare($sql);
$stmt -> execute();

$sql = "INSERT INTO group_login
(firstname, lastname, username, password)
VALUES
(:firstname, :lastname, :username, :password)";
$stmt = $dbConn -> prepare($sql);
$stmt -> execute ( array (":firstname" => "Talanda", ":lastname" => "Williams", ":username" => "twilliams", ":password" => hash('sha1', '0tters')));
$stmt -> execute ( array (":firstname" => "Jordan", ":lastname" => "Horiuchi", ":username" => "jhoriuchi", ":password" => hash('sha1', 'Tiercitil4#')));
$stmt -> execute ( array (":firstname" => "Courtney", ":lastname" => "Dunbar", ":username" => "cdunbar", ":password" => hash('sha1', 'Team4899')));
$stmt -> execute ( array (":firstname" => "Tejus", ":lastname" => "Nanda", ":username" => "tnanda", ":password" => hash('sha1', 'savvy321')));


echo "<p>Your group_login admin table is created!</p>";

$sql2 =  "CREATE TABLE IF NOT EXISTS login_log (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
 	loginDate timestamp NULL DEFAULT CURRENT_TIMESTAMP,
 	username varchar(50) DEFAULT NULL )";

$stmt2 = $dbConn -> prepare($sql2);
$stmt2 -> execute();

echo "<p>Your login_log table is created!</p>";
 
?>


        </div>
        <footer class="footer">
        	 <p><a href="index.php">Back To Team Project</a> < ----- > </p> 
            <p><a href="../index.html">Back To Main Site</a></p>
        </footer>

    </body>

    </html>