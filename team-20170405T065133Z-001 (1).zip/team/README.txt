STEP 1:
Navigate to:
createTable.php

Which Runs Queries:
USStates.sql
StateCapitals.sql
Login_log.sql
(files included for reeview)


To test site, go to the index.php page.
Use logins given in createTable.php


